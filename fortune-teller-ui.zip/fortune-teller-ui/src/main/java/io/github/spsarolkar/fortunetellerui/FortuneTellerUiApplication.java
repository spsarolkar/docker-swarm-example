package io.github.spsarolkar.fortunetellerui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FortuneTellerUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FortuneTellerUiApplication.class, args);
	}
}
